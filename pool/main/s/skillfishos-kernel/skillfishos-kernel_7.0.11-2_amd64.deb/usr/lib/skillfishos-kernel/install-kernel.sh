#!/bin/sh
# Download + install the SkillFishOS kernel out-of-band. Args: <kver> <debver> <reltag>
KVER="$1"; DEBVER="$2"; RELTAG="$3"
BASE="https://github.com/MTSistemi/SkillFishOS/releases/download/${RELTAG}"
IMG="linux-image-${KVER}_${DEBVER}_amd64.deb"
HDR="linux-headers-${KVER}_${DEBVER}_amd64.deb"
log(){ echo "[skillfishos-kernel] $*"; }
# wait (up to 10 min) for any apt/dpkg lock to be released
i=0; while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 && [ "$i" -lt 300 ]; do sleep 2; i=$((i+1)); done
if dpkg-query -W -f='${Status}' "linux-image-${KVER}" 2>/dev/null | grep -q "install ok installed"; then
  log "${KVER} already installed."; exit 0
fi
TMP="$(mktemp -d)"
dl(){ if command -v curl >/dev/null 2>&1; then curl -fSL "$1" -o "$2"; else wget -O "$2" "$1"; fi; }
log "downloading ${KVER} image + headers..."
dl "${BASE}/${IMG}" "${TMP}/${IMG}" || { log "image download failed"; exit 1; }
dl "${BASE}/${HDR}" "${TMP}/${HDR}" || { log "headers download failed"; exit 1; }
log "installing..."
dpkg -i "${TMP}/${IMG}" "${TMP}/${HDR}" || apt-get -f install -y
apt-mark hold "linux-image-${KVER}" "linux-headers-${KVER}" 2>/dev/null || true
command -v update-grub >/dev/null 2>&1 && update-grub || true
rm -rf "${TMP}"
log "${KVER} installed."
